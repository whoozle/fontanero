Greetings, 10k Apart team!

Here's our little application, written in two weeks by two software engineers:
Vladimir Menshakov <vladimir.menshakov@gmail.com> and 
Vladimir Zhuravlev <private.face@gmail.com>

This is simple dungeon crawler inspired by nethack. It contains random 
dungeon generator, dozen of different monster, fix-a-pipe minigame and even
SCARY BOSS MONSTER at the very end of the game.

We found your task very challenging and we could not even think that
we had so much fun while developing this game. We carefully crafted every
byte and invented various optimizations over and over again.
Thank you! :)

Please note! Due the security restrictions this application wont run locally.
You could check our game running on my home box here: 
http://btanks.svalko.org/~megath/fontanero/

Hope you like it! Have fun! :)

PS If you'd need original sources + toolchain we used for optimizing everything,
feel free to contact us, we'll give you an access to private svn repo.

v2 introduced several new features: 
- combining/crafting items
- throwing food into monsters + animation
- better boss strategy
- effect of confusion
- added tile of fixed pipes, better tile for multiple objects
